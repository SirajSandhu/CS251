# include <stdio.h>

void microkernel_sendmsg(char *);

void main() {
	printf("The name is Bond, James Bond.\n");
	printf("Double-O Section of the SIS\n");
	microkernel_sendmsg("Special Intelligence Service");
}

void microkernel_sendmsg(char *a) {
	printf("microkernel: %s\n", a);
}
